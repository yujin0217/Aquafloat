import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getDatabase,
  ref,
  query,
  get,
  limitToLast,
  onChildAdded
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

// ✅ Firebase 설정
const firebaseConfig = {
  apiKey: "AIzaSyBa1j3Kv2J8pkS8-EuIRLUP65BS4YXcFPY",
  authDomain: "fish-tank-92bf4.firebaseapp.com",
  databaseURL: "https://fish-tank-92bf4-default-rtdb.firebaseio.com",
  projectId: "fish-tank-92bf4",
  storageBucket: "fish-tank-92bf4.appspot.com",
  messagingSenderId: "411742072049",
  appId: "1:411742072049:web:a04c0f3a4ed75cb3cb0d50"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const logsRef = ref(database, 'sensor_data/logs');

// ✅ 날짜+시간 형식
function formatDateTime(timestamp) {
  const date = new Date(Number(timestamp) * 1000);
  return date.toLocaleDateString('ko-KR') + ' ' + date.toLocaleTimeString('ko-KR');
}

// ✅ 차트 생성 함수
function createChart(ctxId, label, color) {
  const originalCanvas = document.getElementById(ctxId);
  const canvas = originalCanvas.cloneNode(true);

  const wrapper = document.createElement('div');
  wrapper.style.overflowX = 'auto';
  wrapper.style.width = '100%';
  wrapper.style.marginBottom = '30px';

  wrapper.appendChild(canvas);
  originalCanvas.replaceWith(wrapper);

  return new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label,
        data: [],
        borderColor: color,
        backgroundColor: color.replace("1)", "0.2)"),
        fill: true,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            font: { size: 18 }
          }
        },
        tooltip: {
          titleFont: { size: 16 },
          bodyFont: { size: 14 }
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: '시간',
            font: { size: 16 }
          },
          ticks: {
            font: { size: 12 },
            maxRotation: 45,
            minRotation: 30
          }
        },
        y: {
          title: {
            display: true,
            text: label,
            font: { size: 16 }
          },
          ticks: {
            font: { size: 12 }
          }
        }
      }
    }
  });
}

// ✅ 차트 4개 생성
const tChart = createChart('T', 'T 값 (940nm)', 'rgba(255, 99, 132, 1)');
const uChart = createChart('U', 'U 값 (850nm)', 'rgba(54, 162, 235, 1)');
const vChart = createChart('V', 'V 값 (680nm)', 'rgba(255, 206, 86, 1)');
const wChart = createChart('W', 'W 값 (560nm)', 'rgba(75, 192, 192, 1)');

// ✅ 1. 과거 데이터 불러오기
get(logsRef).then(snapshot => {
  if (!snapshot.exists()) return;

  snapshot.forEach(child => {
    const data = child.val();
    const time = formatDateTime(child.key); // ✅ 날짜+시간

    [[tChart, data.T], [uChart, data.U], [vChart, data.V], [wChart, data.W]].forEach(([chart, value]) => {
      chart.data.labels.push(time);
      chart.data.datasets[0].data.push(value);
    });
  });

  tChart.update(); uChart.update(); vChart.update(); wChart.update();
});

// ✅ 2. 실시간 데이터 수신
const liveQuery = query(logsRef, limitToLast(1));
onChildAdded(liveQuery, (snapshot) => {
  const data = snapshot.val();
  const time = formatDateTime(snapshot.key); // ✅ 실시간도 날짜+시간

  document.getElementById('timestamp').textContent = `데이터 수신 시간: ${time}`;

  [[tChart, data.T], [uChart, data.U], [vChart, data.V], [wChart, data.W]].forEach(([chart, value]) => {
    chart.data.labels.push(time);
    chart.data.datasets[0].data.push(value);
    if (chart.data.labels.length > 100) {
      chart.data.labels.shift();
      chart.data.datasets[0].data.shift();
    }
    chart.update();
  });
});

// ✅ 지도 표시
const map = L.map('map').setView([37.3402, 126.7336], 15);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

const marker = L.marker([37.3402, 126.7336]).addTo(map);
marker.bindPopup('<b>위치: 한국공대</b><br><b>현재 수질 상태:</b> <span id="status">-</span>').openPopup();
