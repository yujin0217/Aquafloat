
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getDatabase, ref, onValue } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js';

const firebaseConfig = {
  apiKey: "AIzaSyBa1j3Kv2J8pkS8-EuIRLUP65BS4YXcFPY",
  authDomain: "fish-tank-92bf4.firebaseapp.com",
  databaseURL: "https://fish-tank-92bf4-default-rtdb.firebaseio.com",
  projectId: "fish-tank-92bf4",
  storageBucket: "fish-tank-92bf4.appspot.com",
  messagingSenderId: "411742072049",
  appId: "1:411742072049:web:a04c0f3a4ed75cb3cb0d50"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const dataRef = ref(database, 'sensor_data/sensor/data');

const now = new Date();
const formatted = `${now.getFullYear()}.${now.getMonth() + 1}.${now.getDate()} ${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;
document.getElementById("current-time").textContent = `현재 시간: ${formatted}`;

function createChart(ctx, label, color) {
  return new Chart(ctx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label,
        data: [],
        borderColor: color,
        backgroundColor: color + '33',
        fill: true,
        tension: 0.3,
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: { title: { display: true, text: '시간' } },
        y: { beginAtZero: true, title: { display: true, text: label } }
      }
    }
  });
}

const charts = {
  T: createChart(document.getElementById('chart-t').getContext('2d'), 'T', 'rgba(255, 99, 132, 1)'),
  U: createChart(document.getElementById('chart-u').getContext('2d'), 'U', 'rgba(54, 162, 235, 1)'),
  V: createChart(document.getElementById('chart-v').getContext('2d'), 'V', 'rgba(255, 206, 86, 1)'),
  W: createChart(document.getElementById('chart-w').getContext('2d'), 'W', 'rgba(75, 192, 192, 1)'),
};

onValue(dataRef, (snapshot) => {
  const data = snapshot.val();
  if (!data) return;

  const now = new Date();
  const time = now.toLocaleTimeString();

  charts.T.data.labels.push(time);
  charts.U.data.labels.push(time);
  charts.V.data.labels.push(time);
  charts.W.data.labels.push(time);

  charts.T.data.datasets[0].data.push(data.T);
  charts.U.data.datasets[0].data.push(data.U);
  charts.V.data.datasets[0].data.push(data.V);
  charts.W.data.datasets[0].data.push(data.W);

  const status = (data.T < 300 && data.U < 300 && data.V < 300 && data.W < 300) ? '양호' : '주의';
  document.getElementById('current-status').textContent = '현재 수질 상태: ' + status;

  Object.values(charts).forEach(chart => {
    if (chart.data.labels.length > 50) {
      chart.data.labels.shift();
      chart.data.datasets[0].data.shift();
    }
    chart.update();
  });
});

document.getElementById("back-button").addEventListener("click", () => {
  window.location.href = "index.html";
});

document.getElementById("download-button").addEventListener("click", () => {
  let csv = "시간,T,U,V,W\n";
  const len = charts.T.data.labels.length;
  for (let i = 0; i < len; i++) {
    const row = [
      charts.T.data.labels[i],
      charts.T.data.datasets[0].data[i],
      charts.U.data.datasets[0].data[i],
      charts.V.data.datasets[0].data[i],
      charts.W.data.datasets[0].data[i]
    ].join(',');
    csv += row + '\n';
  }

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = 'sensor_data.csv';
  link.click();
});
