import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getDatabase, ref, onValue } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js';

const firebaseConfig = {
  apiKey: "AIzaSyBa1j3Kv2J8pkS8-EuIRLUP65BS4YXcFPY",
  authDomain: "fish-tank-92bf4.firebaseapp.com",
  databaseURL: "https://fish-tank-92bf4-default-rtdb.firebaseio.com",
  projectId: "fish-tank-92bf4",
  storageBucket: "fish-tank-92bf4.appspot.com",
  messagingSenderId: "411742072049",
  appId: "1:411742072049:web:a04c0f3a4ed75cb3cb0d50"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

const map = L.map('map').setView([37.3402, 126.7336], 17);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);
L.marker([37.3402, 126.7336]).addTo(map).bindPopup("한국공대");

const dataRef = ref(db, 'sensor_data/sensor/data');
onValue(dataRef, (snapshot) => {
  const data = snapshot.val();
  if (!data) return;
  document.getElementById('current-t').textContent = 'T: ' + data.T;
  document.getElementById('current-u').textContent = 'U: ' + data.U;
  document.getElementById('current-v').textContent = 'V: ' + data.V;
  document.getElementById('current-w').textContent = 'W: ' + data.W;
  const status = data.T > 10 ? '나쁨' : '좋음';
  document.getElementById('current-status').textContent = '현재 수질 상태: ' + status;
});

const camRef = ref(db, 'sensor_data/camera');
onValue(camRef, (snap) => {
  const val = snap.val();
  if (!val) return;
  document.getElementById('latest-img').src = val.lastUrl;
  document.getElementById('cam-heartbeat').textContent =
    '마지막 갱신: ' + new Date(val.lastUnix * 1000).toLocaleTimeString('ko-KR');
});

function updateCurrentTime() {
  const now = new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
  document.getElementById('current-time').textContent = '현재 시간: ' + now;
}
updateCurrentTime();
setInterval(updateCurrentTime, 1000);

document.getElementById('view-detail').addEventListener('click', () => {
  window.location.href = 'graphs.html';
});
