/* Firebase 10.12.2 ───────────────────────────── */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getDatabase, ref, onValue } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js';

const firebaseConfig = {
  apiKey: "AIzaSyBa1j3Kv2J8pkS8-EuIRLUP65BS4YXcFPY",
  authDomain: "fish-tank-92bf4.firebaseapp.com",
  databaseURL: "https://fish-tank-92bf4-default-rtdb.firebaseio.com",
  projectId: "fish-tank-92bf4",
  storageBucket: "fish-tank-92bf4.appspot.com",
  messagingSenderId: "411742072049",
  appId: "1:411742072049:web:a04c0f3a4ed75cb3cb0d50"
};

const app = initializeApp(firebaseConfig);
const db  = getDatabase(app);
const dataRef = ref(db, 'sensor_data/sensor/data');

/* Leaflet 지도 ────────────────────────────────── */
const map = L.map('map').setView([37.3402, 126.7336], 17);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors'
}).addTo(map);
L.marker([37.3402, 126.7336]).addTo(map).bindPopup("한국공대");

/* 현재 시간 (KST) 1초 갱신 ─────────────────────── */
function updateCurrentTime() {
  const kst = new Date().toLocaleString('ko-KR', {
    timeZone: 'Asia/Seoul',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
  document.getElementById('current-time').textContent = `현재 시간: ${kst}`;
}
updateCurrentTime();
setInterval(updateCurrentTime, 1000);

/* 센서 데이터 실시간 표시 ─────────────────────── */
onValue(dataRef, (snapshot) => {
  const data = snapshot.val();
  if (!data) return;

  document.getElementById('current-t').textContent = `T: ${data.T}`;
  document.getElementById('current-u').textContent = `U: ${data.U}`;
  document.getElementById('current-v').textContent = `V: ${data.V}`;
  document.getElementById('current-w').textContent = `W: ${data.W}`;

  // 간단 예시: T 값이 10 초과면 '나쁨'
  const status = (data.T > 10) ? '나쁨' : '좋음';
  document.getElementById('current-status').textContent = `현재 수질 상태: ${status}`;
});

/* 그래프 페이지로 이동 버튼 ──────────────────── */
document.getElementById('view-detail').addEventListener('click', () => {
  window.location.href = 'graphs.html';
});